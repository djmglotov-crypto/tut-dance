Tut Dance 0.4.0 — React Native / Expo, iOS and Android.
The React dance engine and motion data are bundled locally, no server audio processing.
Android: npm install; APP_VARIANT=adults npx expo prebuild --platform android --clean; cd android; ./gradlew assembleRelease. Repeat APP_VARIANT=kids.
iOS: npm install; npx expo prebuild --platform ios; build and sign using Xcode on macOS and an Apple developer account.
Test APKs are not Google Play releases. Screen recording and file sharing inside Android WebView require on-device validation; browser feature detection gives fallback instructions.
