import {defineConfig} from 'vite';export default defineConfig({base:'./',build:{outDir:'../../outputs/tut-v3',emptyOutDir:true}});
